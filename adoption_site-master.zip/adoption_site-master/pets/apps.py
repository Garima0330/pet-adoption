from django.apps import AppConfig


class PetsConfig(AppConfig):
    name = 'pets'
